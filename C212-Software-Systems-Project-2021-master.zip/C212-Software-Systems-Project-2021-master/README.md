# C212-Software-Systems-Project-2021
repository for c212 software systems project

The movie booking system is run in Menu.java. The app is run via the Command line prompt
Other details:
the hardcoded Admin detains are as follows:
Username: ADMIN
Password: ADMINPASSWORD
use those details to log in as an Admin.
For the User PoV, you will obviously have to register an account, etc.
